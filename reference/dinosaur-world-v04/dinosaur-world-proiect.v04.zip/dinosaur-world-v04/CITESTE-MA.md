# Dinosaur World — upgrade editorial v04

Acesta este un proiect separat, importabil în WonderPages. Aplicația v04 nu îl preîncarcă.

- 6 volume, carte de poveste și carte de colorat per volum; engleză/română; proiectul rămâne 3–4 ani.
- Milo, Tia și Pip: psihologie, voce, relații, gesturi și repere vizuale legate de corp. Referințele originale sunt păstrate.
- Story Bible pentru fiecare volum, plan de 12 momente per volum, conflicte și finaluri diferite.
- Volumul 1: scenariu rescris EN/RO, 335 / 344 cuvinte; 12 pagini cu acțiune, emoție, informație nouă, contribuția imaginii, storyboard și hook/payoff.
- Contract v15, 18 criterii de critică separată și cel mult două corecții automate, conform motorului existent.

Import: Proiecte → Importă proiect (.zip). Proiectul apare Pregătit; nu pornește singur. Pornește lucrul când dorești. Documentele pregătite se păstrează; planșele/referințele necesare se produc, apoi se deschide aprobarea seriei. Scenariul pregătit al volumului 1 trece prin critică și continuitate înaintea aprobării demo-ului. Toate aprobările sunt ale utilizatorului.

Unghiurile lipsă, atlasul de expresii și modelul vizual al lui Pip sunt specificate pentru producție, nu prezentate drept imagini deja generate/aprobate. Raporturile propuse pentru reperele corpului se confirmă pe planșe; nu sunt coordonate fixe pe pagină. Nicio ilustrație nouă, carte finală sau probă cu copii nu este pretinsă de acest pachet. Traducerea RO este pregătire editorială și se reverifică în fluxul de adaptare.

Corecții importante: Tia ține frunza cu botul; imaginea îngheață un singur moment; sclipirea din apă este reflexia aceleiași pietricele; ploaia cere adăpost pentru cei doi prieteni. Pana lui Pip este un obiect colecționat, fără modificarea anatomiei personajului.
