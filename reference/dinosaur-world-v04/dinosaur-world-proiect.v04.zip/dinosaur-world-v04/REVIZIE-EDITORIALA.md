# Revizie editorială a pregătirii v04

Această revizie documentează textul și planul efectiv pregătite. Nu închide etapa separată a criticului din aplicație, nu aprobă imagini inexistente și nu atribuie un scor AI sau reacții observate ale copiilor.

## T01 — Age fit: vocabulary, sentence length and conflict intensity match the age profile exactly

Dovadă: Pagina 3: „Tap!” / „Țac!”; pagina 8: întrebarea despre adăpost.

Evaluare: Vocabular concret, cauzalitate simplă și suspans fără pericol real.

## T02 — Coherence: clear beginning, middle and end; every page moves the story forward

Dovadă: Pagini 1–3: descoperire; 4–7: întâlnire/reflexie; 8–9: alegere; 10–12: întoarcere/final.

Evaluare: Fiecare bloc schimbă situația; finalul răspunde dorinței inițiale.

## T03 — Continuity: characters, names, looks and world match the Story Bible

Dovadă: Pagina 9: Tia prinde tulpina cu botul; pagina 12: fiecare la propria casă.

Evaluare: Anatomia și regula celor două case sunt păstrate.

## T04 — Read-aloud rhythm: pleasant to read aloud, no awkward phrasing

Dovadă: „Roll, roll, roll” / „Rostogol, rostogol”; „Splish” / „Pleosc”.

Evaluare: Ritm pentru lectură cu voce tare; verificarea cu o familie rămâne necesară.

## T05 — Illustratability: each page has one clear, visually distinct, drawable moment; consecutive pages never look alike

Dovadă: Paginile 2/7/11 au close-up; 4/6/10/12 au cadru larg.

Evaluare: Fiecare imagine îngheață un moment; nu cere două ipostaze ale aceluiași personaj.

## T06 — Colouring suitability: scenes are not too crowded for the age

Dovadă: Pagina 9: o frunză, două personaje și o pietricică.

Evaluare: Un singur centru de interes și regiuni mari; lizibilitatea lineartului se verifică pe imaginile efective.

## T07 — Safety and values: nothing frightening beyond the age, no stereotypes, positive values

Dovadă: „gentle slope”, ploaie blândă, fără furtună sau apă rapidă.

Evaluare: Conflict potrivit vârstei; nu se fac promisiuni pedagogice certificate.

## T08 — Format: exact page count; text length close to the age guideline (a variation of about a third is fine when the story needs it)

Dovadă: 12 scene, 335 cuvinte EN și 344 RO; maximum 180 caractere EN pe pagină.

Evaluare: Buget orientativ respectat; PDF-ul fiecărei limbi se verifică la producție, fără micșorare ascunsă.

## T09 — Cast: the main character leads; returning characters are re-introduced naturally; the volume follows the cast plan

Dovadă: Pagina 5: Tia se prezintă; Pip nu apare în volumul 1.

Evaluare: Distribuția și introducerea personajelor sunt explicite.

## T10 — Page turns: a few real reveals, the rest quieter; every turn connects to the previous page

Dovadă: Hook 4 → payoff 5, hook 6 → payoff 7, hook 8 → payoff 9.

Evaluare: Răspunsurile sunt pe scene ulterioare; deschiderea fizică se confirmă în preview-ul profilului ales.

## T11 — Reveal pacing: nothing is shown before the page where it is discovered

Dovadă: Tia nu este vizibilă înainte de pagina 5; pietricica lipsește din pagina 1.

Evaluare: Dezvăluirile sunt protejate în must_not_show și scene.

## T12 — Repetition with variation (rule of three, a refrain) that invites the child to join in

Dovadă: „up, up, up”; „roll, roll, roll”; „tap” revine la pagina 11 cu alt rezultat.

Evaluare: Repetiție cu variație și revenire a unui sunet cu payoff.

## T13 — Agency: the main character drives the key actions; secondary characters never dominate

Dovadă: Milo împinge obiectul, o invită pe Tia și observă frunza; apoi îi face loc.

Evaluare: Protagonistul conduce; soluția implică și ajutorul prietenei.

## T14 — Ending: warm and complete, no artificial sequel teaser

Dovadă: „Beside him, the pebble rested too.” / „se odihnea și pietricica”.

Evaluare: Final complet și calm, fără reclamă pentru volumul următor.

## T15 — Clarity: no scene a parent could misread (e.g. friends sleeping together); unambiguous pronouns; natural, non-redundant wording

Dovadă: Pagina 7: un singur obiect real și o reflexie; pagina 12: două case.

Evaluare: Ambiguitățile obiectului duplicat și somnului împreună sunt eliminate.

## T16 — Physical causality: each page has one clear event whose cause and effect make sense

Dovadă: O atingere pornește obiectul; nasul Tiei mișcă apa; adâncitura îl oprește.

Evaluare: Cauzele sunt vizibile, nu înlocuite cu magie sau explicație adultă.

## T17 — No procedural or adult safety-manual language in the story

Dovadă: „A roof for two!” / „Un acoperiș pentru doi!”

Evaluare: Soluția este trăită în poveste, fără instrucțiuni de siguranță sau morală.

## T18 — World rules respected: natural light and weather are not presented as magic

Dovadă: Pagina 2: lumină naturală; pagina 7: reflexie; pagina 8: ploaie blândă.

Evaluare: Regula fără magie rămâne în bible, efecte și scenariu.

## Verificări rămase în producție

Planșele complete și identitatea lui Pip; poziția exactă a reperelor pe atlas aprobat; ilustrațiile și lineartul efective; critică separată pe fiecare revizie; preview/PDF bilingv; lectură cu voce tare cu o familie; proba de tipar. Toate aprobările rămân ale utilizatorului.
